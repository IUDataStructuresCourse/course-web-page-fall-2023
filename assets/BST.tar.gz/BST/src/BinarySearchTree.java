import java.util.LinkedList;
        import java.util.List;
        import java.util.function.BiPredicate;

/**
 * This class implements a generic unbalanced binary search tree (BST).
 */
public class BinarySearchTree<K> {

    /**
     *
     * A Node<K> is a Location (defined in OrderedSet.java), which
     * means that it can be the return value of a search on the tree.
     *
     */

    static class Node<K> {

        K data;
        Node<K> left, right;

        /**
         * Constructs a leaf Node<K> with the given key.
         */
        public Node(K key) {
            this(key, null, null);
        }

        /**
         * Constructs a new Node<K> with the given values for fields.
         */
        public Node(K data, Node<K> left, Node<K> right) {
            this.data = data;
            this.left = left;
            this.right = right;
        }

        /*
         * This method should return the Node<K> in the subtree rooted at 'this'
         * that has the smallest key.
         */
        protected Node<K> first() {
            if (this.left == null)
                return this;
            return this.left.first();
        }


        public String toString() {
            return toStringPreorder(this);
        }

    }

    Node<K> root;
    protected BiPredicate<K, K> lessThan;

    /**
     * Constructs an empty BST, where the data is to be organized according to
     * the lessThan relation.
     */
    public BinarySearchTree(BiPredicate<K, K> lessThan) {
        this.lessThan = lessThan;
    }

    static private <K> String toStringPreorder(Node<K> p) {
        if (p == null)
            return ".";
        String left = toStringPreorder(p.left);
        if (left.length() != 0) left = " " + left;
        String right = toStringPreorder(p.right);
        if (right.length() != 0) right = " " + right;
        String data = p.data.toString();
        return "(" + data + left + right + ")";
    }

    /**
     * Returns a textual representation of this BST.
     */
    public String toString() {
        return toStringPreorder(root);
    }

    /**
     * Finds the Node<K> with the specified key, or if there is none, the parent of
     * where such a Node<K> would be.
     * @param key
     * @param curr  The current Node<K>.
     * @param parent  The parent of the current Node<K>.
     * @return A Node<K> whose data == key or else the parent of where the Node<K> would be.
     */
    protected Node<K> find(K key, Node<K> curr, Node<K> parent) {
        if (curr == null)
            return parent;
        else if (lessThan.test(key, curr.data))
            return find(key, curr.left, curr);
        else if (lessThan.test(curr.data, key))
            return find(key, curr.right, curr);
        else
            return curr;
    }

    /**
     * Looks up the key in this tree and, if found, returns the
     * location containing the key.
     */
    public Node<K> search(K key) {
        Node<K> n = find(key, root, null);
        if (n != null && n.data.equals(key))
            return n;
        else
            return null;
    }

    /**
     * Returns true iff the given key is in this BST.
     */
    public boolean contains(K key) {
        Node<K> p = search(key);
        return p != null;
    }


    // recursive insert, book 4.3.3
    public Node<K> insert_rec(K key) {
        root = insert_helper(key, root);
        return root;
    }

    private Node<K> insert_helper(K key, Node<K> curr) {
        if (curr == null)
            return new Node<>(key, null, null);
        else if (lessThan.test(key, curr.data))
            curr.left = insert_helper(key, curr.left);
        else if (lessThan.test(curr.data, key))
            curr.right = insert_helper(key, curr.right);
        else
            ; // duplicate; do nothing
        return curr;
    }

    public Node<K> insert(K key) {
        Node<K> n = find(key, root, null);
        if (n == null){
            root = new Node<K>(key);
            return root;
        } else if (lessThan.test(key, n.data)) {
            Node<K> x = new Node<K>(key);
            n.left = x;
            return x;
        }  else if (lessThan.test(n.data, key)) {
            Node<K> x = new Node<K>(key);
            n.right = x;
            return x;
        } else
            return null;
    }

    public void remove(K key) {
        root = remove_helper(root, key);
    }

    private Node remove_helper(Node<K> curr, K key) {
        if (curr == null) {
            return null;
        } else if (lessThan.test(key, curr.data)) { // remove in left subtree
            curr.left = remove_helper(curr.left, key);
            return curr;
        } else if (lessThan.test(curr.data, key)) { // remove in right subtree
            curr.right = remove_helper(curr.right, key);
            return curr;
        } else {      // remove this node
            if (curr.left == null) {
                return curr.right;
            } else if (curr.right == null) {
                return curr.left;
            } else {   // two children, replace with first of right subtree
                Node<K> min = curr.right.first();
                curr.data = min.data;
                curr.right = remove_helper(curr.right, min.data);
                return curr;
            }
        }
    }


    public void remove2(K key) {
        root = remove_helper2(root, key);
    }

    protected Node remove_min(Node<K> curr) {
        if (curr == null) {
            return null;
        } else if (curr.left == null) {
            // curr is min
            return curr.right;
        } else {
            // if curr has left child
            curr.left = remove_min(curr.left);
            return curr;
        }
    }

    private Node remove_helper2(Node<K> curr, K key) {
        if (curr == null) {
            return null;
        } else if (lessThan.test(key, curr.data)) { // remove in left subtree
            curr.left = remove_helper2(curr.left, key);
            return curr;
        } else if (lessThan.test(curr.data, key)) { // remove in right subtree
            curr.right = remove_helper2(curr.right, key);
            return curr;
        } else {      // remove this node
            if (curr.left == null) {
                return curr.right;
            } else if (curr.right == null) {
                return curr.left;
            } else {   // two children, replace with first of right subtree
                Node<K> min = curr.right.first();
                curr.data = min.data;
                curr.right = remove_min(curr.right);
                return curr;
            }
        }
    }

}
