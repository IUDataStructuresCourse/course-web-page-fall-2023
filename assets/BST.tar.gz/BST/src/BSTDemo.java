import java.util.ArrayList;
import java.util.function.BiPredicate;

public class BSTDemo {

    static BiPredicate<Integer, Integer> lt = (i, j) -> {
        return i < j;
    };

    public static BinarySearchTree<Integer> buildTree(Integer[] arr, boolean rec) {
        BinarySearchTree<Integer> t = new BinarySearchTree<Integer>(lt);
        for (int i = 0; i < arr.length; ++ i) {
            if (rec)
                t.insert_rec(arr[i]);
            else
                t.insert(arr[i]);
        }
        return t;
    }

    public static void main(String[] args) {
        Integer[] arr   = {8, 3, 1, 6, 4, 7, 10, 14, 13};
        Integer[] input = {6, 9, 15};
        // create two BSTs with the same data
        BinarySearchTree<Integer> t1 = buildTree(arr, true);
        BinarySearchTree<Integer> t2 = buildTree(arr, false);
        System.out.println("t1 after construction: \t\t\t" + t1);
        System.out.println("t2 after construction: \t\t\t" + t2);
        /**
         *           8
         *         /   \
         *        /     \
         *       3       10
         *      / \        \
         *     1   6       14
         *        / \     /
         *       4   7   13
         */
        assert t1.toString().equals(t2.toString());                  // sanity check
        // Search example: 6, 9, 15
        for (Integer k : input)
            System.out.println("searching for " + k + "  in t1 (t2): \t" +
                               t1.find(k, t1.root, null));
        // Insert example: 6, 9, 15
        for (Integer k : input) {
            t1.insert(k);
            t2.insert_rec(k);
        }
        System.out.println("t1 after inserting 6, 9, 15: \t" + t1);  // trees after insertion
        System.out.println("t2 after inserting 6, 9, 15: \t" + t2);
        assert t1.toString().equals(t2.toString());                  // sanity check
        /**
         *           8
         *         /   \
         *        /     \
         *       3       10
         *      / \     /  \
         *     1   6   9   14
         *        / \     /  \
         *       4   7   13  15
         */
        // delete leaf nodes from t1
        t1.remove(7);
        t1.remove(13);
        // delete a node with no right child from t1
        t1.remove(6);
        System.out.println("t1 after deleting 7, 13, 6: \t" + t1);
        /**
         *           8
         *         /   \
         *        /     \
         *       3       10
         *      / \     /  \
         *     1   4   9   14
         *                   \
         *                   15
         */
        // delete a node with no left child from t1
        t1.remove(14);
        System.out.println("t1 after deleting 14: \t\t\t" + t1);
        /**
         *           8
         *         /   \
         *        /     \
         *       3       10
         *      / \     /  \
         *     1   4   9   15
         */
        // delete nodes with both children from t2
        t2.remove(6);
        System.out.println("t2 after deleting 6: \t\t\t" + t2);
        /**
         *           8
         *         /   \
         *        /     \
         *       3       10
         *      / \     /  \
         *     1   7   9   14
         *        /       /  \
         *       4       13  15
         */
        t2.remove(10);
        System.out.println("t2 after deleting 10: \t\t\t" + t2);
        /**
         *           8
         *         /   \
         *        /     \
         *       3       13
         *      / \     /  \
         *     1   7   9   14
         *        /          \
         *       4           15
         */
        t2.remove(3);
        System.out.println("t2 after deleting 3: \t\t\t" + t2);
        /**
         *           8
         *         /   \
         *        /     \
         *       4       13
         *      / \     /  \
         *     1   7   9   14
         *                   \
         *                   15
         */
        t2.remove(13);
        System.out.println("t2 after deleting 13: \t\t\t" + t2);
        /**
         *           8
         *         /   \
         *        /     \
         *       4       14
         *      / \     /  \
         *     1   7   9   15
         */
    }
}
